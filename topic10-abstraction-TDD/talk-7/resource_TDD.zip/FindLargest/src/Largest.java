
public class Largest {

	public static int findLargest (int[] list)
	{
		int index = 0;
		int max = 0;
				
		for (index = 0; index < list.length; index++)
		{
			if (list[index] > max)
			{
				max = list[index];
			}
		}

		return max;
	}

}



