
public class Driver {

	public static void main(String args[])
	{
		int list[] = {2,5,3,4};
		int largestNumber = Largest.findLargest(list);
		System.out.println("Largest number is: " + largestNumber);
	}
}

