import java.util.Scanner;

/**
 * This class controls the Gym application. 
 * 
 * It displays the following basic menu for the Gym and processes the user input.
 * 
 * <pre>
 * 
 * Gym Menu
 * ---------
 * 1) Add a member
 * 2) List all members
 * 3) Remove a member (by index)
 * 4) Number of members in the gym
 * ---------
 * 5) List gym details
 * 6) List members with ideal starting weight
 * 7) List members with a specific BMI category
 * 8) List all members stats imperically and metrically
 * 0) Exit
 * ==>> 
 * </pre>
 * 
 * @author Siobhan Drohan (sdrohan@wit.ie)
 * @version 1.0 (02/02/2017)
 * 
 */
public class MenuController
{
    private Scanner input;
    private Gym gym;

    /**
     * The default constructor.
     * 
     * The constructor creates an instance of the Scanner class.
     * 
     * It also asks the user to enter the gym name, manager name and gym phone number.  These details are used to create an instance of the Gym.  
     * 
     * The final task in the constructor is to run the menu.
     */
    public MenuController()
    {
        input = new Scanner(System.in);    

        //read in the details....
        System.out.println("Please enter the Gym...");
        System.out.print("\tName: ");
        String gymName = input.nextLine();
        System.out.print("\tManager name: ");
        String managerName = input.nextLine();
        System.out.print("\tPhone number: ");
        String phoneNumber = input.nextLine();

        gym = new Gym(gymName, managerName, phoneNumber);
        runMenu();
    }

    /*
     * mainMenu() - This method displays the menu for the application, 
     * reads the menu option that the user entered and returns it.
     * 
     * @return     the users menu choice
     */
    private int mainMenu()
    { 
        System.out.println("\fGym Menu");
        System.out.println("---------");     
        System.out.println("  1) Add a member");    
        System.out.println("  2) List all members");
        System.out.println("  3) Remove a member (by index)");
        System.out.println("  4) Number of members in the gym");
        System.out.println("---------"); 
        System.out.println("  5) List gym details");               
        System.out.println("  6) List members with ideal starting weight");        
        System.out.println("  7) List members with a specific BMI category"); 
        System.out.println("  8) List all members stats imperically and metrically"); 
        System.out.println("  0) Exit");
        System.out.print("==>> ");
        int option = input.nextInt();
        return option;
    }

    /*
     * This is the method that controls the loop.
     */
    private void runMenu()
    {
        int option = mainMenu();
        while (option != 0)
        {

            switch (option)
            {
                case 1:    addMember();
                           break;
                case 2:    System.out.println(gym.listMembers());
                           break;
                case 3:    deleteMember();
                           break;
                case 4:    System.out.println("Number of members: " + gym.numberOfMembers());
                           break;
                case 5:    System.out.println(gym.toString());
                           break;
                case 6:    System.out.println(gym.listMembersWithIdealWeight());
                           break;
                case 7:    System.out.print("Please enter the category to search by: ");
                           String category = input.nextLine();
                           category = input.nextLine();
                           System.out.println(gym.listBySpecificBMICategory(category));
                           break;
                case 8:    System.out.println(gym.listMemberDetailsImperialAndMetric());
                           break;
                default:   System.out.println("Invalid option entered: " + option);
                           break;
            }

            //pause the program so that the user can read what we just printed to the terminal window
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();  //this second read is required - bug in Scanner class; a String read is ignored straight after reading an int.

            //display the main menu again
            option = mainMenu();
        }

        //the user chose option 0, so exit the program
        System.out.println("Exiting... bye");
        System.exit(0);
    }

    private void addMember()
    {
        System.out.println("Please enter the following member details...");
        System.out.print("\tId (between 100001 and 999999): ");
        int memberId = input.nextInt();
        System.out.print("\tName (max 30 chars): ");
        String memberName = input.nextLine();
        memberName = input.nextLine();
        System.out.print("\tAddress: ");
        String memberAddress = input.nextLine();
        System.out.print("\tHeight (between 1 and 3 metres): ");
        double height = input.nextDouble();
        System.out.print("\tStarting weight (between 35kg and 250kg): ");
        double startingWeight = input.nextDouble();
        System.out.print("\tGender (M/F): ");
        String gender = input.next().toUpperCase();

        gym.add(new Member(memberId, memberName, memberAddress, 
                height, startingWeight, gender));
    }

    
    private void deleteMember()
    {
        //list the products and ask the user to choose the product to edit
        System.out.println(gym.listMembers());

        if (gym.numberOfMembers() != 0){   
            //only process the delete if products exist in the ArrayList
            System.out.print("Index of member to delete ==>");
            int index = input.nextInt();

            if (index < gym.numberOfMembers() ){    
                //if the index number exists in the ArrayList, delete it from the ArrayList
                gym.remove(index);
                System.out.println("Member deleted.");
            }
            else
            {
                System.out.println("There is no member for this index number");
            }
        }
    }    
}
