import java.util.ArrayList;

/**
 * <pre>
 * This class handles a collection of Member classes.
 *
 * The details stored for a gym include:
 *      Gym name
 *      Manager name
 *      Phone number
 *      An ArrayList collection of its Members
 *   
 * Along with the standard constructors, getters, setters and toString methods listed below, 
 * there are specific methods that:
 *    
 *       - List all the members that have an ideal starting weight.
 *       - List all the members of a specific BMI category.
 *       - List all the members' weight and height both imperically and metrically.
 *   
 * </pre>
 * 
 * @author Siobhan Drohan (sdrohan@wit.ie)
 * @version 1.0 (01 Feb 2017)
 */
public class Gym
{
    private String gymName;       
    private String managerName;   
    private String phoneNumber;   
    private ArrayList<Member> members;

    /**
     * Constructor for objects of class Gym.  Within this constructor, the phone number instance 
     * field is set to "unknown" and the members ArrayList is instantiated.
     * 
     * @param gymName     The gym name must be no more than 30 characters.  If the 
     *                    entered name exceeds 30 characters, the extra characters will be 
     *                    truncated and only only the first 30 characters will be retained. 
     * @param managerName No validation is performed on the manager name field.
    */
    public Gym(String gymName, String managerName){
        setGymName(gymName);
        setManagerName(managerName);
        this.phoneNumber = "unknown";
        members = new ArrayList<>();
    }

    /**
     * Constructor for objects of class Gym.  Within this constructor, the members ArrayList is instantiated.
     * 
     * @param gymName     The gym name must be no more than 30 characters.  If the 
     *                    entered name exceeds 30 characters, the extra characters will be 
     *                    truncated and only only the first 30 characters will be retained. 
     * @param managerName No validation is performed on the manager name field.
     * @param phoneNumber A check is done on the phone number to ensure that it is a number.
     *                    If the phone number is not a number, it is set to "unknown".
     */
    public Gym(String gymName, String managerName, String phoneNumber){
        setGymName(gymName);
        setManagerName(managerName);
        if (onlyContainsNumbers(phoneNumber)){
           this.phoneNumber = phoneNumber;
        }
        else{
            this.phoneNumber = "unknown";
        }
        members = new ArrayList<>();
    }

    //***********************************************************************************
    //  ARRAY LIST HANDLING METHODS
    //*********************************************************************************** 
    /**
     *  Adds a member to the gym collection.
     *  
     *  @param member The member object that will be added to the gym collection.
     */    
    public void add(Member member){
        members.add(member);
    }
    
    /**
     *  Removes a member from the gym collection.
     *  
     *  @param index The index number of the member object that will be removed from the gym collection.
     */  
    public void remove(int index){
        members.remove(index);
    }
    
    /**
     *  Returns the number of members stored in the gym collection.
     *  
     *  @return The number of the member object currently stored in the gym collection.
     */  
    public int numberOfMembers(){
        return members.size();
    }

    /**
     *  Returns a String representing all the members stored in the gym collection.
     *  
     *  @return String representing all the members stored in the gym collection.  The String returned is similar to this structure, 
     *  with the preceeding number representing the index number of the member within the collection:
     * 
     * <pre>
     * 
     *    0: member's toString() format
     *    1: member's toString() format
     *    2: member's toString() format
     *   
     * </pre>
     */      
    public String listMembers(){
        if (members.size() > 0){
            String listOfMembers = "";
            for (int i = 0; i < numberOfMembers(); i++){
                listOfMembers += i + ": " + members.get(i) + "\n";        
            }
            return listOfMembers;
        }
        else{
            return "There are no members in the gym";
        }
    }
    
    //***********************************************************************************
    //  ARRAY LIST INTERROGATION AND SUMMATION METHODS
    //***********************************************************************************
    /**
     * List all the members that have an ideal starting weight.
     * 
     * @return The list of members (i.e. use the toString method here) that have an ideal starting weight based on the 
     * devine method.  
     * 
     * <pre>
     * 
     * If there are no members with an ideal starting weight, the message 
     *      "There are no members in the gym with an ideal weight" should be returned.  
     *      
     * If there are no members in the gym, the message 
     *      "There are no members in the gym" should be returned.
     * </pre>
     */
    public String listMembersWithIdealWeight(){
        if (members.size() > 0){
            String listOfMembers = "";
            for (Member member: members){
                if (member.isIdealBodyWeight()){
                    listOfMembers += member.toString() + "\n";        
                }
            }
            if (listOfMembers.equals("")){
                return "There are no members in the gym with an ideal weight";
            }

            return listOfMembers;
        }
        else{
            return "There are no members in the gym";
        }
    }
    
    /**
     * List all the members of a specific BMI category.
     * 
     * @param category - The category you wish to search members by.  
     * 
     * <pre>
     * 
     * The specific categories are:
     *     "VERY SEVERELY UNDERWEIGHT"
     *     "SEVERELY UNDERWEIGHT"
     *     "UNDERWEIGHT"
     *     "NORMAL"
     *     "OVERWEIGHT"
     *     "MODERATELY OBESE"
     *     "SEVERELY OBESE"
     *     "VERY SEVERELY OBESE" 
     *     
     * This method also allows you to search by key words e.g. "OBESE" will return members in the following categories:
     *     "MODERATELY OBESE"
     *     "SEVERELY OBESE"
     *     "VERY SEVERELY OBESE"      
     * Note:  In this situation, the members are NOT sorted by category, they are just displayed as is.
     * 
     * </pre>
     * 
     * @return The list of members whose BMI falls into the category passed as a parameter.
     * <pre>
     * 
     * If there are no members in the BMI category, the message 
     *      "There are no members in the gym in this BMI category" should be returned.  
     * 
     * If there are no members in the gym, the message 
     *      "There are no members in the gym" should be returned.
     * </pre>
     */ 
    public String listBySpecificBMICategory(String category){
        if (members.size() > 0){
            String listOfMembers = "";
            for (Member member: members){
                if (member.determineBMICategory().toUpperCase().contains(category.toUpperCase())){
                    listOfMembers += member.toString() + "\n";        
                }
            }
            if (listOfMembers.equals("")){
                return "There are no members in the gym in this BMI category";
            }
            return listOfMembers;
        }
        else{
            return "There are no members in the gym";
        }
    }

    /**
     * List all the members' weight and height both imperically and metrically.
     * 
     * @return Each member in the gym with the weight and height listed both imperically and metrically.
     * 
     * <pre>
     * The format of the output is like so:
     * 
     *     Joe Soap:     xx kg (xxx lbs)     x.x metres (xx inches).
     *     Joan Soap:    xx kg (xxx lbs)     x.x metres (xx inches).  
     * 
     * If there are no members in the gym, the message 
     *      "There are no members in the gym" should be returned.
     * </pre>
     */    
    public String listMemberDetailsImperialAndMetric(){
        if (members.size() > 0){
            String listOfMembers = "";
            for (Member member: members){
                 listOfMembers += member.getMemberName() + ":\t\t"
                                + member.getStartingWeight() + " kg (" 
                                + member.convertWeightKGtoPounds() + " lbs)\t\t"
                                + member.getHeight() + " metres ("
                                + member.convertHeightMetresToInches() + " inches)."
                                + "\n";        
            }
            return listOfMembers;
        }
        else{
            return "There are no members in the gym.";
        }
    }

    //***********************************************************************************
    //  GETTERS
    //***********************************************************************************
    /** 
     * Returns the name of the gym.
     * @return the gym name
     */    
    public String getGymName(){
        return gymName;
    }

    /**
     * Returns the name of the manager
     * @return the manager name
     */
    public String getManagerName(){
        return managerName;
    }
    
    /**
     * Returns the phone number of the gym
     * @return the gym phone number
     */
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    //***********************************************************************************
    //  SETTERS
    //*********************************************************************************** 
    /**
     * Updates the gym name field
     * @param gymName The gym name must be no more than 30 characters.  If the 
     *                   entered name exceeds 30 characters, the extra characters will be 
     *                   truncated and only only the first 30 characters will be retained. 
     */    
    public void setGymName(String gymName)
    {
        if ( gymName.length() <=30 ){ 
            this.gymName = gymName;
        }
        else{
            this.gymName = gymName.substring(0,30);
        }
    }

    /**
     * Updates the manager name field
     * @param managerName No validation is performed on the manager name field.
     */
    public void setManagerName(String managerName){
        this.managerName = managerName;
    }

    /**
     * Updates the gym phone number field
     * @param phoneNumber A check is done on the phone number to ensure that it is a number.
     *                    If the phone number is not a number, the field is not updated.
     */
    public void setPhoneNumber(String phoneNumber){
        if (onlyContainsNumbers(phoneNumber)){
            this.phoneNumber = phoneNumber;
        }
    }
    
    /**
     * Returns a human-readable String representation of the object state.
     * 
     * @return a String version of the Gym object.  The String returned is similar to this structure:
     * 
     * <pre>
     * 
     *    Gym name: High Flyer Gym, Manager: Eddie the Eagle, Phone Number: 0519665654343.
     *    
     *    List of members in the gym:
     *    (list all of the members here)
     *    
     * </pre>
     */
     public String toString(){
        return ( "Gym name: " + gymName 
               + ", Manager: " + managerName
               + ", Phone Number: " + phoneNumber
               + ".\n\nList of members in the gym:\n"
               + listMembers());
    }  

    //***********************************************************************************
    //  HELPER METHOD(S)
    //*********************************************************************************** 
    private boolean onlyContainsNumbers(String text) {
        try {
            Integer.parseInt(text);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    } 
}