/**
 * <pre>
 * This class is the template for a single Member.
 *
 * The details stored for a member include:
 *      Member ID
 *      Member Name
 *      Member Address
 *      Height (in metres)
 *      Starting Weight (in kgs)
 *   
 * Along with the standard constructors, getters, setters and 
 * toString methods listed below, there are specific methods that:
 *    
 *       - Convert the weight from KGs to Pounds
 *       - Convert the height from Metres to Inches
 *       - Determines if a start weight is ideal (based on the devine method)
 *       - Calculates the BMI for the member
 *       - Determines the BMI category based on their calculated BMI
 *   
 * </pre>
 * 
 * @author Siobhan Drohan (sdrohan@wit.ie)
 * @version 1.0 (01 Feb 2017)
 */
public class Member
{
    private int memberId;            
    private String memberName;       
    private String memberAddress;    
    private double height;           
    private double startingWeight;
    private String gender;

    /**
     * Constructor for objects of class Member.
     * 
     * @param memberId        The member's id is 6 digits long i.e. between 100000 (exclusive) and 
     *                        999999 (inclusive).  If an invalid member id is entered, set the member
     *                        id to a default value of 100000.
     * @param memberName      The member's name should be no more than 30 characters.  If the 
     *                        entered name exceeds 30 characters, the extra characters will be 
     *                        truncated and only only the first 30 characters will be retained.        
     * @param memberAddress   There is no validation on the member's address.
     * @param height          The member's height is measured in Metres.  A minimum height of
     *                        one metre (inclusive) is allowed and a maximum height of three metres (inclusive).
     * @param startingWeight  The member's weight upon joining the gym (in kgs).  A minimum 
     *                        weight of 35kg (inclusive) and a max of 250kg (inclusive) is permitted in the gym.
     * @param gender          The member's gender i.e. can be either "M" or "F".  If not 
     *                        specified, default to "Unspecified".
     */
    public Member(int memberId, String memberName, String memberAddress, 
                  double height, double startingWeight, String gender){
        if ((memberId > 100000) && ( memberId <=999999)){
            this.memberId = memberId;
        }
        else{
            this.memberId = 100000;
        }

        if (memberName.length() <= 30){
            this.memberName = memberName;
        }
        else{
            this.memberName = memberName.substring(0,30);
        }

        this.memberAddress = memberAddress;

        if ((height >= 1) && (height <= 3)){
            this.height = height;
        }
        else{
            this.height = 0;
        }
        
        if ((startingWeight >= 35) && (startingWeight <= 250)){
            this.startingWeight = startingWeight;
        }
        else{
            this.startingWeight = 0;
        }
        
        if ((gender.toUpperCase().equals("M")) || (gender.toUpperCase().equals("F"))){
            this.gender = gender.toUpperCase();
        }
        else{
            this.gender = "Unspecified";
        }
    }
        
    /**
     * This method returns the member weight converted from KGs to pounds.
     * @return member weight converted from KGs to pounds.
     *         The number returned is truncated to two decimal places.
     **/   
    public double convertWeightKGtoPounds(){
        return toTwoDecimalPlaces(startingWeight * 2.2);
    }

    /**
     * This method returns the member height converted from metres to inches.
     * @return member height converted from metres to inches using the formula: meters 
     * multiplied by 39.37.  The number returned is truncated to two decimal places.
     **/   
    public double convertHeightMetresToInches(){
        return toTwoDecimalPlaces(height * 39.37);
    }
    
    /**
     * This method returns a boolean to indicate if the member has an ideal
     * body weight based on the Devine formula.
     * 
     * <pre>
     * For males, an ideal body weight is:   50 kg + 2.3 kg for each inch over 5 feet.
     * For females, an ideal body weight is: 45.5 kg + 2.3 kg for each inch over 5 feet.
     * 
     * Note:  if no gender is specified, return the result of the female calculation.
     * 
     * </pre>
     * 
     * @return Returns true if the result of the devine formula is within 2 kgs (inclusive) of the 
     *         starting weight; false if it is outside this range.
     */
    public boolean isIdealBodyWeight()
    {
        double fiveFeet = 60.0;
        double idealBodyWeight;

        double inches = convertHeightMetresToInches();
        
        if (inches <= fiveFeet){
            if (gender.equals("M")){   
                idealBodyWeight = 50;  
            }
            else{   
                idealBodyWeight = 45.5;
            }
        }
        else{
            if (gender.equals("M")){   
                idealBodyWeight = 50 + ((inches - fiveFeet) * 2.3);  
            }
            else{   
                idealBodyWeight = 45.5 + ((inches - fiveFeet) * 2.3);
            } 
        }
        
        return (      (idealBodyWeight <= (startingWeight + 2.0)) 
                   && (idealBodyWeight >= (startingWeight - 2.0)) 
               );
    }
    
    /**
     * This method calculates the BMI value for the member.
     * 
     * The formula used for BMI is weight divided by the square of the height.
     * 
     * @return the BMI value for the member.  The number returned is truncated to two decimal places.
     **/   
    public double calculateBMI(){
        if (this.height <= 0)
            return 0;
        else
            return toTwoDecimalPlaces(this.startingWeight / (this.height * this.height));
    }  
    
    /**
     * This method determines the BMI category that the member belongs to.
     * 
     * <pre>
     * 
     * The category is determined by the magnitude of the members BMI according to the following:
     * 
     *     BMI less than    15   (exclusive)                      is "VERY SEVERELY UNDERWEIGHT"
     *     BMI between      15   (inclusive) and 16   (exclusive) is "SEVERELY UNDERWEIGHT"
     *     BMI between      16   (inclusive) and 18.5 (exclusive) is "UNDERWEIGHT"
     *     BMI between      18.5 (inclusive) and 25   (exclusive) is "NORMAL"
     *     BMI between      25   (inclusive) and 30   (exclusive) is "OVERWEIGHT"
     *     BMI between      30   (inclusive) and 35   (exclusive) is "MODERATELY OBESE"
     *     BMI between      35   (inclusive) and 40   (exclusive) is "SEVERELY OBESE"
     *     BMI greater than 40   (inclusive)                      is "VERY SEVERELY OBESE"
     *     
     * </pre>
     * 
     * @return 
     * <pre>
     * The format of the String is similar to this (note the double quotes around the category):
     *     "NORMAL".
     * </pre>
     */
    public String determineBMICategory()
    {
        double bmi = calculateBMI();
        
        if      (bmi < 15)    return "\"VERY SEVERELY UNDERWEIGHT\"";
        else if (bmi < 16)    return "\"SEVERELY UNDERWEIGHT\"";
        else if (bmi < 18.5)  return "\"UNDERWEIGHT\"";
        else if (bmi < 25)    return "\"NORMAL\"";
        else if (bmi < 30)    return "\"OVERWEIGHT\"";
        else if (bmi < 35)    return "\"MODERATELY OBESE\"";
        else if (bmi < 40)    return "\"SEVERELY OBESE\"";
        else                  return "\"VERY SEVERELY OBESE\"";
    }
   
    /*
     * This is a private helper method.  It ensures that all double data returned from this class
     * is restricted to two decimal places.  Note:  this method does not round 
     */
    private  double toTwoDecimalPlaces( double num){   
        return (int)(num *100 ) / 100.0; 
    }        

    
    //***********************************************************************************
    //  GETTERS
    //***********************************************************************************
    /** 
     * Returns the id for the member.
     * @return the member's id
     */
    public int getMemberId(){
        return memberId;
    }   

    /**
     * Returns the member's name.
     * @return the member's name
     */       
    public String  getMemberName(){
        return memberName;
    }
    
    /**
     * Returns the member's address.
     * @return the member's address
    **/
    public String getMemberAddress(){
        return memberAddress;
    }
    
    /**
     *  Returns the member's height.
     * @return the member's height
    **/
    public double getHeight(){
        return height;
    }
    
    /**
     * Returns the member's starting weight.
     * @return the member's starting weight
     */ 
    public double getStartingWeight(){
        return startingWeight;
    }
 
    /**
     * Returns the member's gender.
     * @return the member's gender
    **/
    public String getMemberGender(){
        return gender;
    }
    
    //***********************************************************************************
    //  SETTERS
    //*********************************************************************************** 
    /**
     * Updates the member id field.
     * @param memberId The member's id is 6 digits long i.e. between 100000 (exclusive) 
     *                 and 999999 (inclusive).
     */
    public void setMemberId(int memberId){ 
        if ((memberId > 100000) && ( memberId <=999999)){
            this.memberId = memberId;
        }
    }

    /** 
     * Updates the member name field.
     * @param memberName The member's name should be no more than 30 characters.  If the 
     *                   entered name exceeds 30 characters, the extra characters will be 
     *                   truncated and only only the first 30 characters will be retained.        
     */
    public void  setMemberName(String memberName){
        if (memberName.length() <= 30){
            this.memberName = memberName;
        }
        else{
            this.memberName = memberName.substring(0,30);
        }
    }      

    /**
     * Updates the member address field.
     * @param memberAddress There is no validation on the member's address.
     */
    public void setMemberAddress(String memberAddress){
        this.memberAddress = memberAddress;
    }

    /**
     * Updates the member height field.
     * @param height The member's height is measured in Metres.  A minimum height of
     *               one metre is allowed and a maximum height of three metres.
     */
    public void setHeight( double height){
        if ((height >= 1) && (height <= 3)){
            this.height = height;
        }   
    }
    
    /**
     * Updates the member starting weight field.
     * @param startingWeight  The member's weight upon joining the gym (in kgs).  A minimum 
     *                        weight of 35kg and a max of 250kg is permitted in the gym.
     */
    public void setStartingWeight( double startingWeight){
        if ((startingWeight >= 35) && (startingWeight <= 250)){
            this.startingWeight = startingWeight;
        }
    }  

    /** 
     * Updates the member's gender field.
     * @param gender The member's gender i.e. can be either "M" or "F". All other values are ignored.
     */
    public void setGender(String gender)
    {
        if ((gender.toUpperCase().equals("M")) || (gender.toUpperCase().equals("F"))){
            this.gender = gender.toUpperCase();
        }
    }
    
    /**
     * Returns a human-readable String representation of the object state.
     * 
     * @return a string version of the Member object.  The String returned is similar to this structure:
     * 
     * <pre>
     * 
     *     Member id: 123456, Name: Joe Soap, Address: 12 High Street, Waterford.
     *         Height: 2 metres, Starting Weight: 74 kgs, BMI of 18.5 (NORMAL).
     * </pre>
     */
    public String toString(){
        return ("Member id : " + memberId
              + ", Name:"  + memberName 
              + ", Address:" + memberAddress + "."
              + "\n\tHeight: "+ toTwoDecimalPlaces(height) + " metres"
              + ",  Starting Weight: " + toTwoDecimalPlaces(startingWeight) + " kgs"
              + ", BMI of " + calculateBMI()
              + " (" + determineBMICategory() + ")." + "\n");
    }
}