
//If a class implements this interface, the particular entity can be deleted

public interface Deleteable {

	void delete(int index);
}
