/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author (TO DO: Insert your name here.)
 * @version (TO DO: Insert today's date here.)
 */
class Book
{
    // The fields
    private String author;
    private String title;
    // TO DO:  Add a field to store the ISBN
    // TO DO:  Add a field to store the cost of the book
    
    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String author, String title)
    {
        //TO DO: set the author and title fields to the contents of 
        //       the passed parameters.
    }

    /**
     * Set the author, title, ISBN and cost fields when this object
     * is constructed.
     */
    //TO DO: write a second constructor that has four parameters and use
    //       the data in these parameters to update the instance fields
    //       Make sure that the cost of the book is greater than zero.
    
    
    // TO DO: Add a getter method for each instance field (i.e. you 
    //        will write four methods here.
    
    
    // TO DO: Add a setter method for each instance field (i.e. you 
    //        will write four methods here.
    //        When writing the setter for the cost field, only update the cost fields
    //        if the value entered is greater than zero.
    
}
