/**
 * 
 */
package models;

import java.util.Date;

public class DairyProduct extends Product {

	private Date bestBeforeDate;

	public DairyProduct(String productName, int productCode, 
						double unitCost, boolean inCurrentProductLine,
						Date bestBeforeDate) {
		super(productName, productCode, unitCost, inCurrentProductLine);
		this.bestBeforeDate = bestBeforeDate;
	}

	/**
	 * @return the bestBeforeDate
	 */
	public Date getBestBeforeDate() {
		return bestBeforeDate;
	}

	/**
	 * @param bestBeforeDate the bestBeforeDate to set
	 */
	public void setBestBeforeDate(Date bestBeforeDate) {
		this.bestBeforeDate = bestBeforeDate;
	}
	
	public String toString() {
		return super.toString() + "\n\tBest before date: " + bestBeforeDate;
	}
	
}
