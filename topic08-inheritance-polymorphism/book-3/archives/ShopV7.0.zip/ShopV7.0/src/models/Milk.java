package models;

import java.util.Date;

public class Milk extends DairyProduct {

	protected int cartonSize;
	protected String fatContent;
	
	public Milk(String productName, int productCode, double unitCost, boolean inCurrentProductLine,
			    Date bestBeforeDate, int cartonSize, String fatContent) {
		super(productName, productCode, unitCost, inCurrentProductLine, bestBeforeDate);
		this.cartonSize = cartonSize;
		this.fatContent = fatContent;
	}

	/**
	 * @return the cartonSize
	 */
	public int getCartonSize() {
		return cartonSize;
	}

	/**
	 * @param cartonSize the cartonSize to set
	 */
	public void setCartonSize(int cartonSize) {
		this.cartonSize = cartonSize;
	}

	/**
	 * @return the fatContent
	 */
	public String getFatContent() {
		return fatContent;
	}

	/**
	 * @param fatContent the fatContent to set
	 */
	public void setFatContent(String fatContent) {
		this.fatContent = fatContent;
	}
	
	public String toString() {
		return super.toString() + ", carton size: " + cartonSize + ", fat content: " + fatContent + ".  (MILK)";
	}
}
