package models;

import java.util.Date;

public class Butter extends DairyProduct {

	protected int packetGrams;
	protected boolean isSalted;
	
	public Butter(String productName, int productCode, double unitCost, boolean inCurrentProductLine,
			      Date bestBeforeDate, int packetGrams, boolean isSalted) {
		super(productName, productCode, unitCost, inCurrentProductLine, bestBeforeDate);
		this.packetGrams = packetGrams;
		this.isSalted = isSalted;
	}

	/**
	 * @return the packetGrams
	 */
	public int getPacketGrams() {
		return packetGrams;
	}

	/**
	 * @param packetGrams the packetGrams to set
	 */
	public void setPacketGrams(int packetGrams) {
		this.packetGrams = packetGrams;
	}

	/**
	 * @return the isSalted
	 */
	public boolean isSalted() {
		return isSalted;
	}

	/**
	 * @param isSalted the isSalted to set
	 */
	public void setSalted(boolean isSalted) {
		this.isSalted = isSalted;
	}	
	
	public String toString() {
		return super.toString() + ", grams: " + packetGrams + ", is Salted: " + isSalted + ".  (BUTTER)";
	}
}
