package resource_01;

import java.util.Scanner;

/**
 * A class for testing our primitive array code.
 * 
 * @author Siobhan Drohan (sdrohan@wit.ie) 
 * @version V1.0 (30/01/2017)
 */
public class PrimitiveArray
{
    private Scanner scanner;

    public static void main(String args[])
    {
    	PrimitiveArray arrayExamples = new PrimitiveArray();
    	//arrayExamples.askForFiveNumbers();
    	//arrayExamples.askForFiveNumbers();
    	//arrayExamples.askForFiveNumbersAndRemember();    
    	//arrayExamples.askForFiveNumbersUsingArrays1();
    	//arrayExamples.askForFiveNumbersUsingArrays2();
    	//arrayExamples.askForFiveNumbersUsingArrays3(3);
    	//arrayExamples.askForFiveNumbersUsingArrays4();
    	//arrayExamples.forLoopPractice1();
    	//arrayExamples.forLoopPractice2();
    	//arrayExamples.forLoopPractice3();
    	//arrayExamples.forLoopPractice4();
    	//arrayExamples.sentinelBasedWhileLoop();
    	//arrayExamples.flagBasedWhileLoop();
    	//arrayExamples.flagBasedWhileLoopBetter();
        if (arrayExamples.flagBasedWhileLoopReturn()){
            System.out.println("There is at least one odd number in the array");
        }
        else{
            System.out.println("There are NO odd numbers in the array");
        }
    	
    }
    public PrimitiveArray()
    {
        scanner = new Scanner(System.in);
    }

    public void askForFiveNumbers()
    {
        int n;
        int sum = 0;
        for (int i = 0; i<5; i++)  
        {    
            System.out.print("Please enter a number: ");
            n = scanner.nextInt();
            sum += n;  
        }
        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void askForFiveNumbersAndRemember()
    {
        int n1, n2, n3, n4, n5;
        int sum = 0;

        System.out.print("Please enter a number: ");
        n1 = scanner.nextInt();
        System.out.print("Please enter a number: ");
        n2 = scanner.nextInt();
        System.out.print("Please enter a number: ");
        n3 = scanner.nextInt();
        System.out.print("Please enter a number: ");
        n4 = scanner.nextInt();
        System.out.print("Please enter a number: ");
        n5 = scanner.nextInt();
        sum = n1 + n2 + n3 + n4 + n5;  

        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void askForFiveNumbersUsingArrays1()
    {
        int numbers[] = new int[5];
        int sum = 0;
        for (int i = 0; i<5; i++)  
        {    
            System.out.print("Please enter a number: ");
            numbers[i] = scanner.nextInt(); 
        }

        for (int i = 0; i<5; i++)  
        {    
            sum += numbers[i];  
        }
        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void askForFiveNumbersUsingArrays2()
    {
        int numbers[] = new int[5];
        int sum = 0;
        for (int i = 0; i<5; i++)  
        {    
            System.out.print("Please enter a number: ");
            numbers[i] = scanner.nextInt(); 
            sum += numbers[i];  
        }
        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void askForFiveNumbersUsingArrays3(int size)
    {
        int numbers[] = new int[size];
        int sum = 0;
        for (int i = 0; i < numbers.length; i++)  
        {    
            System.out.print("Please enter a number: ");
            numbers[i] = scanner.nextInt(); 
            sum += numbers[i];  
        }
        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void askForFiveNumbersUsingArrays4()
    {
        System.out.print("How many numbers to you want to enter: ");
        int size = scanner.nextInt();
        int numbers[] = new int[size];

        int sum = 0;
        for (int i = 0; i < numbers.length; i++)  
        {    
            System.out.print("Please enter a number: ");
            numbers[i] = scanner.nextInt(); 
            sum += numbers[i];  
        }
        System.out.println("The sum of the values you typed in is: " + sum);
    }

    public void forLoopPractice1()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};

        for (int i = 0; i < numbers.length; i++)
        {
            System.out.println("Number " + (i+1) + ": " + numbers[i]);
        }
    }

    public void forLoopPractice2()
    {
        int[] fib = new int[40];

        fib[0] = 0;
        fib[1] = 1;

        for (int i = 2; i < fib.length; i++)
        {
            fib[i] = fib[i-1] + fib[i-2];
        }

        for (int i = 0; i < fib.length; i++)
        {
            System.out.println("Number " + (i+1) + ": " + fib[i]);
        }
    }

    public void forLoopPractice3()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};

        for (int currentNumber : numbers)
        {
            System.out.println("Number: " + currentNumber);
        }
    }

    public void forLoopPractice4()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};

        int i = 1;
        for (int currentNumber : numbers)
        {
            System.out.println("Number " + (i) + ": " + currentNumber);
            i++;
        }
    }

    public void sentinelBasedWhileLoop()
    {
        int sum = 0;

        System.out.print("Please enter an age (-1 ends input): ");
        int ageInput = scanner.nextInt();

        while (ageInput != -1)
        {
            sum += ageInput;
            System.out.print("Please enter an age (-1 ends input): ");
            ageInput = scanner.nextInt();
        }

        System.out.println("The sum of the ages in the room is: " + sum);
    }

    public void flagBasedWhileLoop()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};
        boolean oddNumberInArray = false;

        for (int currentNumber : numbers)
        {
            if (currentNumber % 2 == 1)
            {
                oddNumberInArray = true;
            }
        }        

        if (oddNumberInArray == true)
        {
            System.out.println("There is at least one odd number in the array");
        }
        else
        {
            System.out.println("There are NO odd numbers in the array");
        }
    }

    public void flagBasedWhileLoopBetter()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};
        boolean oddNumberInArray = false;

        for (int currentNumber : numbers)
        {
            if (currentNumber % 2 == 1)
            {
                oddNumberInArray = true;
            }
        }        

        if (oddNumberInArray)
        {
            System.out.println("There is at least one odd number in the array");
        }
        else
        {
            System.out.println("There are NO odd numbers in the array");
        }
    }

    public boolean flagBasedWhileLoopReturn()
    {
        int[] numbers = { 4, 1, 22, 9, 14, 3, 9};
        
        for (int currentNumber : numbers)
        {
            if (currentNumber % 2 == 1)
            {
                return true;
            }
        }        
        
        return false;
    }

}
